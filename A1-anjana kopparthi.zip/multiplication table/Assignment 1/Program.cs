﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Program
    {
        
     static void Main(string[] args)
        {
            int multiplicand, multiplier;
            multiplicand = int.Parse (Console.ReadLine());
            for (multiplier = 1; multiplier <= 10; multiplier++) 
            {
                
                Console.WriteLine("{0}x{1}={2}", multiplicand, multiplier, multiplicand*multiplier);
            }
            

            
        }
    }
}
